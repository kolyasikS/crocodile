export const SET_ROOM = 'SET_ROOM';
export const ADD_PLAYER = 'ADD_PLAYER';
export const ADD_MESSAGE = 'ADD_MESSAGE';
export const CLEAR = 'CLEAR';
